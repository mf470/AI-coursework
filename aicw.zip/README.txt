The code for question 1 is in the the file 'A-star question.py'. The implementation 
for this is for a general N-puzzle. The program has the start and goal nodes from
Figure 1 hardcoded, however the program asks the user if they wish to use their own 
start and goal states. The user is then asked to input these.

The code for question 2.2 is in the file 'K-means question.py'. This code uses my 
own K-means algorithm. When run it will run k-means for 10 clusters on the digits 
dataset, show the centroids and print the accuracy of the clustering. Other parts
of the code used for analysis including creating an elbow and silhouette plots 
and finding the average accuracy are in the file but commented out by default.

The code used when analysing the pokemon dataset in question 2.4 is in the file
'Pokemon question.py'. This needs the pokemon.csv file in the same directory 
for it to work. The analysis carried out on the data is in the pokemon.xlsx
excel file